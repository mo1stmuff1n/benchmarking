#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void matrixMultiplication(double** a, double** b, double** c, int n) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            c[i][j] = 0;
            for (int k = 0; k < n; k++) {
                c[i][j] += a[i][k] * b[k][j];
            }
        }
    }
}


double** allocateMatrix(int n) {
    double** matrix = (double**)malloc(n * sizeof(double*));
    for (int i = 0; i < n; i++) {
        matrix[i] = (double*)malloc(n * sizeof(double));
    }
    return matrix;
}


void freeMatrix(double** matrix, int n) {
    for (int i = 0; i < n; i++) {
        free(matrix[i]);
    }
    free(matrix);
}


void fillMatrix(double** matrix, int n) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            matrix[i][j] = ((double) rand() / (RAND_MAX));
        }
    }
}

int main() {
    srand(time(NULL));

    int sizes[] = {10, 50, 100, 150, 200};
    int num_sizes = sizeof(sizes) / sizeof(sizes[0]);

    for (int s = 0; s < num_sizes; s++) {
        int n = sizes[s];
        printf("Matrix size: %d x %d\n", n, n);


        double** a = allocateMatrix(n);
        double** b = allocateMatrix(n);
        double** c = allocateMatrix(n);


        fillMatrix(a, n);
        fillMatrix(b, n);

        clock_t start = clock();

        matrixMultiplication(a, b, c, n);

        clock_t end = clock();

        double executionTime = ((double) (end - start)) / CLOCKS_PER_SEC * 1000; // Convert to milliseconds

        long memoryUsed = 3 * n * n * sizeof(double);

        printf("Execution Time: %.2f ms\n", executionTime);
        printf("Estimated Memory Usage: %ld bytes (%.2f MB)\n", memoryUsed, memoryUsed / (1024.0 * 1024));

        freeMatrix(a, n);
        freeMatrix(b, n);
        freeMatrix(c, n);
    }

    return 0;
}
