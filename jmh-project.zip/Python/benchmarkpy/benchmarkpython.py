import numpy as np
import pytest
from memory_profiler import memory_usage

def matrix_multiply(a, b):
    n = len(a)
    c = [[0] * n for _ in range(n)]
    for i in range(n):
        for j in range(n):
            for k in range(n):
                c[i][j] += a[i][k] * b[k][j]
    return c

@pytest.fixture
def setup_matrices():
    size = 200
    A = np.random.rand(size, size)
    B = np.random.rand(size, size)
    return A, B

@pytest.mark.benchmark(min_rounds=5)
def test_matrix_multiply(benchmark, setup_matrices):
    A, B = setup_matrices


    mem_usage_before = memory_usage(max_usage=True)

    result = benchmark(matrix_multiply, A, B)

    mem_usage_after = memory_usage(max_usage=True)


    print(f"Memory usage before: {mem_usage_before}")
    print(f"Memory usage after: {mem_usage_after}")

    assert result is not None
